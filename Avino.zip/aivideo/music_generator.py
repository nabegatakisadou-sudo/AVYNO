"""Musik latar buatan sendiri (sintesis dari nol, tanpa sampel/lagu pihak lain) sehingga bebas masalah hak cipta.
Semua trek dibuat melingkar (circular) agar bisa diulang mulus oleh aplikasi."""
import numpy as np, wave
SR = 22050
rng = np.random.default_rng(7)

def hz(m): return 440.0 * 2 ** ((m - 69) / 12)

class Track:
    def __init__(self, seconds):
        self.n = int(SR * seconds); self.b = np.zeros(self.n)
    def add(self, sig, start):
        idx = (int(start * SR) + np.arange(len(sig))) % self.n
        np.add.at(self.b, idx, sig)

def t_(d): return np.arange(int(SR * d)) / SR

def pad(m, dur, amp, att=1.2, rel=1.5, harm=(1, .5, .25, .12), det=0.4):
    t = t_(dur + rel); f = hz(m)
    env = np.clip(np.minimum(t / att, (dur + rel - t) / rel), 0, 1)
    s = sum(a * (np.sin(2*np.pi*(f*(k+1)+det*k)*t) + np.sin(2*np.pi*(f*(k+1)-det*k)*t)) for k, a in enumerate(harm))
    return amp * env * s / 2

def bell(m, amp, dec=1.6):
    t = t_(dec * 3); f = hz(m)
    return amp * np.exp(-t / dec) * (np.sin(2*np.pi*f*t) + .35*np.sin(2*np.pi*f*2.76*t) + .15*np.sin(2*np.pi*f*5.4*t))

def kick(amp):
    t = t_(.3); ph = 2*np.pi*np.cumsum(50 + 90*np.exp(-t/.05))/SR
    return amp * np.exp(-t/.11) * np.sin(ph)

def noise_hit(dur, dec, amp, hp=True):
    t = t_(dur); n = rng.standard_normal(len(t))
    if hp: n = np.diff(n, prepend=0)
    return amp * n * np.exp(-t/dec) / 2

def pluck(m, dur, amp, harm, dec):
    t = t_(dur); f = hz(m)
    return amp * np.exp(-t/dec) * sum(a*np.sin(2*np.pi*f*(k+1)*t) for k, a in harm)

def delay(tr, secs, fb=.35, taps=2):
    d = int(secs * SR); acc = tr.b.copy()
    for k in range(1, taps + 1): acc += (fb ** k) * np.roll(tr.b, d * k)
    tr.b = acc

def save(tr, name, peak=.8, soft=False):
    x = tr.b - tr.b.mean()
    if soft: x = np.tanh(1.4 * x / np.max(np.abs(x)))
    x = x / np.max(np.abs(x)) * peak
    with wave.open(name, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype('<i2').tobytes())
    return x

# ---------- CALM: Am-F-C-G, 60 bpm, 32 dtk ----------
c = Track(32); chords = [(45, (57, 60, 64, 69)), (41, (53, 57, 60, 65)), (48, (55, 60, 64, 67)), (43, (55, 59, 62, 67))]
for i, (bass, notes) in enumerate(chords):
    s = i * 8
    c.add(pad(bass, 8, .30, 1.0, 2.0, harm=(1, .15)), s)
    for m in notes: c.add(pad(m, 8, .10, 1.6, 2.2), s)
pent = [81, 84, 88, 91, 93]
for k in range(16):
    c.add(bell(pent[(k * 3 + k // 4) % 5], .09), k * 2 + (0.5 if k % 3 == 0 else 0))
delay(c, .75, .4, 3); save(c, 'music_calm.wav', .8)

# ---------- CINEMATIC: Dm-Bb-F-C, 70 bpm, 8 bar ----------
beat = 60 / 70; L = beat * 32; cn = Track(L); chords = [(38, (50, 53, 57, 62)), (34, (46, 53, 58, 65)), (41, (53, 57, 60, 65)), (36, (48, 52, 55, 60))]
for i, (bass, notes) in enumerate(chords):
    s = i * beat * 8
    cn.add(pad(bass, beat * 8, .35, 2.2, 2.5, harm=(1, .45, .3, .2, .12, .08)), s)
    for m in notes: cn.add(pad(m, beat * 8, .09, 2.5, 2.8, harm=(1, .6, .4, .3, .2, .15, .1)), s)
    t = t_(1.4); ph = 2*np.pi*np.cumsum(70 - 25*(1 - np.exp(-t/.25)))/SR
    cn.add(.5 * np.exp(-t/.5) * np.sin(ph), s); cn.add(.5 * np.exp(-t/.5) * np.sin(ph), s + beat * 4)
    cn.add(noise_hit(1.0, .25, .05, hp=False), s)
for k in range(8): cn.add(bell(74 + [0, 3, 7, 10][k % 4], .06, 2.0), k * beat * 4 + beat * 2)
delay(cn, beat * .75, .45, 3); save(cn, 'music_cinematic.wav', .8)

# ---------- ENERGETIC: C-G-Am-F, 110 bpm, 16 bar ----------
beat = 60 / 110; en = Track(beat * 64); prog = [(36, (60, 64, 67)), (43, (59, 62, 67)), (45, (60, 64, 69)), (41, (57, 60, 65))]
for bar in range(16):
    bass, tri = prog[bar // 4]; s = bar * beat * 4
    for b in range(4):
        en.add(kick(.7), s + b * beat)
        if b in (1, 3): en.add(noise_hit(.25, .06, .45), s + b * beat)
    for e in range(8):
        en.add(noise_hit(.08, .018, .22 if e % 2 else .10), s + e * beat / 2)
        if e % 2: en.add(pluck(bass, .3, .35, [(1, 1), (2, .5), (3, .3), (4, .15)], .12), s + e * beat / 2)
    for st in (0, 1.5):
        for m in tri: en.add(pluck(m + 12, .35, .09, [(1, 1), (3, .33), (5, .2), (7, .14)], .12), s + st * beat)
save(en, 'music_energetic.wav', .85, soft=True)

# ---------- pemeriksaan ----------
for nm in ('calm', 'cinematic', 'energetic'):
    with wave.open(f'music_{nm}.wav') as w:
        d = np.frombuffer(w.readframes(w.getnframes()), '<i2') / 32768
    print(nm, f'{len(d)/SR:.1f} dtk', 'puncak %.2f' % np.abs(d).max(), 'rms %.1f dBFS' % (20*np.log10(np.sqrt((d**2).mean()))),
          'selisih sambungan %.3f' % abs(d[0] - d[-1]), 'NaN' if np.isnan(d).any() else 'ok')
