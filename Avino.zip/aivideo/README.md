# AI Video Editor & Content Generator — Tahap 1 (kerangka)

## Status jujur
- BELUM DIUJI: kode ini ditulis tanpa Android SDK, jadi belum pernah di-build. Perbaikan kecil saat Gradle sync / build kemungkinan diperlukan.
- Sudah ada: backend script AI (kunci API aman di server, token + rate limit), alur ide → script → suara → visual → timeline → ekspor dengan status per langkah, cache, dan "Coba lagi" yang hanya mengulang langkah yang gagal, abstraksi provider, ekspor MP4 lewat Media3.
- Opsi 100% GRATIS: script lewat Google Gemini (isi GEMINI_API_KEY dari aistudio.google.com, tanpa kartu kredit, dibatasi laju; kosongkan ANTHROPIC_API_KEY). Tanpa TTS_KEY suara memakai Edge TTS (id-ID-GadisNeural, tidak resmi dan kadang ditolak 403), tanpa IMG_KEY gambar memakai foto stok Pixabay (isi PIXABAY_KEY, gratis) atau Pexels (PEXELS_KEY; Pexels sempat menjeda kunci baru; kredit ke Pexels wajib ditampilkan). Isi TTS_KEY/IMG_KEY untuk beralih ke penyedia berbayar.
- Suara dan gambar: endpoint `/api/tts` dan `/api/image` sudah ada, format default mengikuti API gaya OpenAI (belum diuji). Isi `TTS_KEY` dan `IMG_KEY`; untuk penyedia lain ubah `_call_tts` / `_call_image` di `backend/main.py`.
- Subtitle kata-per-kata (kata aktif berwarna lime) ditempel ke video saat ekspor. Waktu kata masih PERKIRAAN dari panjang huruf; untuk presisi pakai speech-to-text/forced alignment. Ukuran font (`AbsoluteSizeSpan` di `Subtitles.kt`) perlu disesuaikan saat uji.
- Musik latar: pilih suasana (Calm/Cinematic/Energik/Tanpa). Backend menyajikan lagu dari folder `backend/music/` (`calm.mp3`, `cinematic.mp3`, `energetic.mp3`) — isi HANYA dengan lagu berlisensi yang boleh Anda pakai. Volume otomatis turun selama narasi, ada fade in/out, dan lagu diulang sampai video selesai. Ducking masih sederhana (level rendah konstan karena narasi mengisi seluruh video).
- Editor timeline: setelah bahan selesai, pengguna meninjau klip (gambar + potongan narasi + subtitle): geser kiri/kanan, pisah, hapus, potong awal/akhir narasi, dan edit teks subtitle. Subtitle dan ekspor selalu dibuat ulang dari kondisi klip terbaru. Suara dibuat per segmen supaya klip bisa diatur tanpa merusak sinkron.
- Tampilan mengikuti desain: Beranda, Buat Video (rasio, durasi, gaya, suara pria/wanita, musik), progres, editor, dan hasil (judul/deskripsi/hashtag + tombol salin; video tersimpan ke galeri). Fitur yang belum dikodekan (Ide Konten, Template, Suara AI, Gambar AI, Proyek, Setelan, skor SEO, Paywall, Auto Edit) ditandai "Segera" atau tidak ditampilkan, bukan dipalsukan. Font Plus Jakarta Sans belum dipasang (pakai font bawaan).
- Ide Konten (Gemini/Claude membuat 12 ide dari satu niche, tiap ide langsung mengisi form) dan Template (6 gaya: Edukasi, Motivasi, Fakta, Top 5, Storytelling, Berita; memengaruhi struktur script) sudah aktif. Alamat dasar backend (/) kini menjawab {"status":"ok"} untuk uji lewat browser.
- Setelan berisi "Tes koneksi" (memeriksa alamat backend, token, dan penyedia AI yang aktif lewat /api/ping). Pesan galat dari backend kini ditampilkan jelas (token salah, batas laju, kunci belum diisi).
- Musik latar (Calm, Cinematic, Energik) KINI BAWAAN di dalam aplikasi (res/raw), dibuat dari nol oleh `music_generator.py` sehingga bebas masalah hak cipta dan tidak butuh server. Ini musik sintetis sederhana; untuk menggantinya, timpa file `music_calm.wav`, `music_cinematic.wav`, `music_energetic.wav` di `android/app/src/main/res/raw/` dengan lagu berlisensi milik Anda (WAV/MP3, nama sama; kalau MP3 ubah ekstensi di `GenerationViewModel`).
- Belum ada: editor timeline manual, kredit/Play Billing, login.

## Backend
    cd backend && pip install -r requirements.txt
    export ANTHROPIC_API_KEY=... APP_TOKEN=ganti-token-ini TTS_KEY=... IMG_KEY=...
    uvicorn main:app --host 0.0.0.0 --port 8000

## Android
Buka folder `android/` di Android Studio, sinkronkan Gradle, lalu Run. Alamat bawaan kini https://avyno-1.onrender.com; isi kolom alamat saat menjalankan Build APK untuk menimpanya. Saat rilis: pakai HTTPS, matikan cleartext, dan jangan hardcode token (pakai login).


## Cara membangun APK
**A. Android Studio (disarankan, perlu laptop/PC)**
1. Ekstrak zip, buka folder `android/` di Android Studio, tunggu Gradle sync.
2. Hubungkan HP (USB debugging) atau pakai emulator, tekan Run. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.
3. Ganti `BASE_URL` dan `APP_TOKEN` di `app/build.gradle.kts` ke alamat backend Anda (HTTPS) sebelum dipasang di HP sungguhan.

**B. GitHub Actions (tanpa Android Studio)**
1. Buat repository di GitHub, unggah ISI folder `aivideo/` (folder `android`, `backend`, `.github`, dst.) ke cabang `main`.
2. Buka tab Actions → Build APK → Run workflow. Setelah selesai, unduh `app-debug.apk` dari bagian Artifacts.
3. Di HP: izinkan "pasang dari sumber tidak dikenal", lalu buka file APK.

Backend harus berjalan di server yang bisa diakses HP (mis. Render, Railway, VPS). `10.0.2.2` hanya berlaku untuk emulator.

## Panduan khusus HP (tanpa laptop)
Lihat `build-apk-dari-zip.yml`. Ringkasnya: unggah zip ini ke repository GitHub privat, buat workflow dari file itu, isi secret `APP_TOKEN`, jalankan sekali untuk mengekstrak backend, deploy folder `aivideo/backend` ke Render (Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`, env: ANTHROPIC_API_KEY, APP_TOKEN, TTS_KEY, IMG_KEY), lalu jalankan workflow lagi dengan mengisi alamat Render untuk mendapat `app-debug.apk`.
Catatan: APP_TOKEN tertanam di APK. Ini cukup untuk uji pribadi, tetapi ganti dengan login pengguna sebelum dirilis ke publik.
