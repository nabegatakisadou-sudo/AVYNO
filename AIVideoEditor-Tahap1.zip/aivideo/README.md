# AI Video Editor & Content Generator — Tahap 1 (kerangka)

## Status jujur
- BELUM DIUJI: kode ini ditulis tanpa Android SDK, jadi belum pernah di-build. Perbaikan kecil saat Gradle sync / build kemungkinan diperlukan.
- Sudah ada: backend script AI (kunci API aman di server, token + rate limit), alur ide → script → suara → visual → timeline → ekspor dengan status per langkah, cache, dan "Coba lagi" yang hanya mengulang langkah yang gagal, abstraksi provider, ekspor MP4 lewat Media3.
- Suara dan gambar: endpoint `/api/tts` dan `/api/image` sudah ada, format default mengikuti API gaya OpenAI (belum diuji). Isi `TTS_KEY` dan `IMG_KEY`; untuk penyedia lain ubah `_call_tts` / `_call_image` di `backend/main.py`.
- Subtitle kata-per-kata (kata aktif berwarna lime) ditempel ke video saat ekspor. Waktu kata masih PERKIRAAN dari panjang huruf; untuk presisi pakai speech-to-text/forced alignment. Ukuran font (`AbsoluteSizeSpan` di `Subtitles.kt`) perlu disesuaikan saat uji.
- Musik latar: pilih suasana (Calm/Cinematic/Energik/Tanpa). Backend menyajikan lagu dari folder `backend/music/` (`calm.mp3`, `cinematic.mp3`, `energetic.mp3`) — isi HANYA dengan lagu berlisensi yang boleh Anda pakai. Volume otomatis turun selama narasi, ada fade in/out, dan lagu diulang sampai video selesai. Ducking masih sederhana (level rendah konstan karena narasi mengisi seluruh video).
- Editor timeline: setelah bahan selesai, pengguna meninjau klip (gambar + potongan narasi + subtitle): geser kiri/kanan, pisah, hapus, potong awal/akhir narasi, dan edit teks subtitle. Subtitle dan ekspor selalu dibuat ulang dari kondisi klip terbaru. Suara dibuat per segmen supaya klip bisa diatur tanpa merusak sinkron.
- Belum ada: editor timeline manual, kredit/Play Billing, login.

## Backend
    cd backend && pip install -r requirements.txt
    export ANTHROPIC_API_KEY=... APP_TOKEN=ganti-token-ini TTS_KEY=... IMG_KEY=...
    uvicorn main:app --host 0.0.0.0 --port 8000

## Android
Buka folder `android/` di Android Studio, sinkronkan Gradle, lalu Run. Emulator mengakses backend lewat `10.0.2.2:8000` (ubah `BASE_URL` di `app/build.gradle.kts`). Saat rilis: pakai HTTPS, matikan cleartext, dan jangan hardcode token (pakai login).


## Cara membangun APK
**A. Android Studio (disarankan, perlu laptop/PC)**
1. Ekstrak zip, buka folder `android/` di Android Studio, tunggu Gradle sync.
2. Hubungkan HP (USB debugging) atau pakai emulator, tekan Run. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.
3. Ganti `BASE_URL` dan `APP_TOKEN` di `app/build.gradle.kts` ke alamat backend Anda (HTTPS) sebelum dipasang di HP sungguhan.

**B. GitHub Actions (tanpa Android Studio)**
1. Buat repository di GitHub, unggah ISI folder `aivideo/` (folder `android`, `backend`, `.github`, dst.) ke cabang `main`.
2. Buka tab Actions → Build APK → Run workflow. Setelah selesai, unduh `app-debug.apk` dari bagian Artifacts.
3. Di HP: izinkan "pasang dari sumber tidak dikenal", lalu buka file APK.

Backend harus berjalan di server yang bisa diakses HP (mis. Render, Railway, VPS). `10.0.2.2` hanya berlaku untuk emulator.
