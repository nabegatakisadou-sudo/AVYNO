"""Backend perantara: API key AI hanya ada di sini, tidak pernah di APK."""
import json, os, time
from collections import defaultdict
import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field

app = FastAPI(title="AI Video Backend")
KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("SCRIPT_MODEL", "claude-sonnet-5-5")
TOKEN = os.environ.get("APP_TOKEN", "")
_hits: dict[str, list[float]] = defaultdict(list)

def guard(request: Request, auth: str, limit=20, per=60):
    if not TOKEN or auth != f"Bearer {TOKEN}":
        raise HTTPException(401, "Tidak diizinkan")
    ip, now = request.client.host, time.time()
    _hits[ip] = [t for t in _hits[ip] if now - t < per]
    if len(_hits[ip]) >= limit:
        raise HTTPException(429, "Terlalu banyak permintaan")
    _hits[ip].append(now)

class ScriptReq(BaseModel):
    topic: str = Field(min_length=3, max_length=300)
    duration: int = Field(30, ge=10, le=90)
    language: str = "Indonesia"
    style: str = "Edukasi"

@app.post("/api/script")
async def script(req: ScriptReq, request: Request, authorization: str = Header(default="")):
    guard(request, authorization)
    prompt = (
        f"Buat script video pendek berdurasi {req.duration} detik tentang: {req.topic}\n"
        f"Bahasa: {req.language}. Gaya: {req.style}. Struktur: hook, 2-3 informasi, kesimpulan, CTA.\n"
        "Jangan membuat klaim kesehatan berlebihan. Balas HANYA JSON valid tanpa teks lain:\n"
        '{"title":str,"description":str,"hashtags":[str],"segments":[{"start":int,"end":int,'
        '"type":"hook|info|conclusion|cta","narration":str,"visual":str}]}'
    )
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": KEY, "anthropic-version": "2023-06-01"},
            json={"model": MODEL, "max_tokens": 1500, "messages": [{"role": "user", "content": prompt}]},
        )
    if r.status_code != 200:
        raise HTTPException(502, "Penyedia AI gagal")
    text = "".join(b.get("text", "") for b in r.json()["content"]).strip()
    text = text.removeprefix("```json").removesuffix("```").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        raise HTTPException(502, "Format respons AI tidak valid")

# Tambahkan /api/tts dan /api/image dengan pola yang sama (guard + panggil provider pilihan Anda).


# ---- Suara (TTS) dan gambar: provider diatur lewat variabel lingkungan ----
# Format default mengikuti API gaya OpenAI. Untuk penyedia lain, ubah dua fungsi _call_tts/_call_image.
import base64
from fastapi import Response

TTS_URL = os.environ.get("TTS_URL", "https://api.openai.com/v1/audio/speech")
TTS_KEY = os.environ.get("TTS_KEY", "")
TTS_MODEL = os.environ.get("TTS_MODEL", "gpt-4o-mini-tts")
TTS_VOICE = os.environ.get("TTS_VOICE", "alloy")
IMG_URL = os.environ.get("IMG_URL", "https://api.openai.com/v1/images/generations")
IMG_KEY = os.environ.get("IMG_KEY", "")
IMG_MODEL = os.environ.get("IMG_MODEL", "gpt-image-1")
SIZES = {"9:16": "1024x1536", "4:5": "1024x1536", "16:9": "1536x1024", "1:1": "1024x1024"}

class TtsReq(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    voice: str = "default"

class ImageReq(BaseModel):
    prompt: str = Field(min_length=3, max_length=1000)
    ratio: str = "9:16"

async def _call_tts(text: str, voice: str) -> bytes:
    async with httpx.AsyncClient(timeout=120) as c:
        r = await c.post(TTS_URL, headers={"Authorization": f"Bearer {TTS_KEY}"},
                         json={"model": TTS_MODEL, "input": text, "voice": voice})
    if r.status_code != 200:
        raise HTTPException(502, "Penyedia suara gagal")
    return r.content

async def _call_image(prompt: str, ratio: str) -> bytes:
    async with httpx.AsyncClient(timeout=180) as c:
        r = await c.post(IMG_URL, headers={"Authorization": f"Bearer {IMG_KEY}"},
                         json={"model": IMG_MODEL, "prompt": prompt, "size": SIZES.get(ratio, "1024x1536")})
    if r.status_code != 200:
        raise HTTPException(502, "Penyedia gambar gagal")
    return base64.b64decode(r.json()["data"][0]["b64_json"])

@app.post("/api/tts")
async def tts(req: TtsReq, request: Request, authorization: str = Header(default="")):
    guard(request, authorization, limit=10)
    if not TTS_KEY:
        raise HTTPException(501, "TTS belum dikonfigurasi")
    voice = TTS_VOICE if req.voice == "default" else req.voice
    return Response(await _call_tts(req.text, voice), media_type="audio/mpeg")

@app.post("/api/image")
async def image(req: ImageReq, request: Request, authorization: str = Header(default="")):
    guard(request, authorization, limit=30)
    if not IMG_KEY:
        raise HTTPException(501, "Provider gambar belum dikonfigurasi")
    return Response(await _call_image(req.prompt, req.ratio), media_type="image/png")


# ---- Musik latar: file lagu BERLISENSI milik Anda di folder music/ (calm.mp3, cinematic.mp3, energetic.mp3) ----
from fastapi.responses import FileResponse

MUSIC_DIR = os.environ.get("MUSIC_DIR", "music")

@app.get("/api/music/{mood}")
async def music(mood: str, request: Request, authorization: str = Header(default="")):
    guard(request, authorization)
    if mood not in {"calm", "cinematic", "energetic"}:
        raise HTTPException(404, "Suasana musik tidak dikenal")
    path = os.path.join(MUSIC_DIR, f"{mood}.mp3")
    if not os.path.isfile(path):
        raise HTTPException(404, "Letakkan lagu berlisensi di folder music/")
    return FileResponse(path, media_type="audio/mpeg")
