package com.example.aivideo.data

import kotlinx.serialization.Serializable

@Serializable data class ScriptRequest(val topic: String, val duration: Int, val language: String, val style: String)
@Serializable data class Segment(val start: Int, val end: Int, val type: String, val narration: String, val visual: String)
@Serializable data class ScriptResult(
    val title: String = "", val description: String = "",
    val hashtags: List<String> = emptyList(), val segments: List<Segment>,
)

enum class Step(val label: String) {
    SCRIPT("Script"), VOICE("Suara"), VISUAL("Visual"), MUSIC("Musik"), TIMELINE("Timeline"), SUBTITLE("Subtitle"), EXPORT("Ekspor")
}
enum class Status { PENDING, RUNNING, DONE, FAILED }

/** Satu klip timeline: gambar + potongan narasi [fromMs, toMs] dari file suara + teks subtitle. */
data class Clip(
    val id: Int, val image: String, val voice: String, val voiceMs: Long,
    val fromMs: Long, val toMs: Long, val text: String,
) { val durationMs: Long get() = toMs - fromMs }

data class UiState(
    val topic: String = "", val duration: Int = 30, val ratio: String = "9:16",
    val status: Map<Step, Status> = Step.entries.associateWith { Status.PENDING },
    val script: ScriptResult? = null, val voices: List<String> = emptyList(), val images: List<String> = emptyList(),
    val mood: String? = "calm", val music: String? = null,
    val voice: String = "female", val style: String = "Edukasi", val outputUri: String? = null,
    val clips: List<Clip> = emptyList(), val selected: Int = 0, val cues: List<Cue> = emptyList(),
    val output: String? = null, val error: String? = null,
)
