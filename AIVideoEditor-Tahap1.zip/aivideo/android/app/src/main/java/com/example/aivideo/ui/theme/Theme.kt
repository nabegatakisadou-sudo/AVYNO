package com.example.aivideo.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Lime = Color(0xFFC6F432); val Ink = Color(0xFF0E0F13); val Card = Color(0xFF181A21)
val Chip = Color(0xFF22252E); val Muted = Color(0xFFA3A9B8); val Light = Color(0xFFF2F3F7)

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Lime, onPrimary = Ink, background = Ink, onBackground = Light,
        surface = Card, onSurface = Light, surfaceVariant = Chip),
    content = content,
)
