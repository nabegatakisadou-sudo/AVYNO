package com.example.aivideo.data

import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan

/** Satu baris subtitle (beberapa kata) dengan waktu mulai tiap kata. */
data class Cue(val startMs: Long, val endMs: Long, val words: List<String>, val wordStartsMs: List<Long>)

object SubtitleEngine {
    /**
     * Waktu kata DIPERKIRAKAN: durasi klip dibagi sebanding panjang huruf tiap kata.
     * Untuk sinkron presisi, ganti dengan hasil speech-to-text/forced alignment dari audio suara.
     */
    fun buildFromClips(clips: List<Clip>, maxWords: Int = 4): List<Cue> {
        var t = 0L
        return clips.flatMap { c -> cuesFor(c.text, t, t + c.durationMs, maxWords).also { t += c.durationMs } }
    }

    private fun cuesFor(text: String, startMs: Long, endMs: Long, maxWords: Int): List<Cue> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val total = words.sumOf { it.length + 1 }.toDouble()
        var acc = 0.0
        val starts = words.map { w ->
            val s = startMs + ((endMs - startMs) * acc / total).toLong()
            acc += w.length + 1; s
        }
        return words.indices.chunked(maxWords).map { idx ->
            val end = if (idx.last() + 1 < words.size) starts[idx.last() + 1] else endMs
            Cue(starts[idx.first()], end, idx.map { words[it] }, idx.map { starts[it] })
        }
    }

    /** Teks pada waktu [tMs]: putih tebal di latar gelap, kata aktif berwarna lime. */
    fun textAt(cues: List<Cue>, tMs: Long): SpannableString {
        val cue = cues.firstOrNull { tMs >= it.startMs && tMs < it.endMs } ?: return SpannableString(" ")
        val active = cue.wordStartsMs.indexOfLast { it <= tMs }.coerceAtLeast(0)
        val text = cue.words.joinToString(" ")
        val sp = SpannableString(text)
        val f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        sp.setSpan(AbsoluteSizeSpan(56), 0, text.length, f)
        sp.setSpan(StyleSpan(Typeface.BOLD), 0, text.length, f)
        sp.setSpan(ForegroundColorSpan(Color.WHITE), 0, text.length, f)
        sp.setSpan(BackgroundColorSpan(0xB30E0F13.toInt()), 0, text.length, f)
        var pos = 0
        cue.words.forEachIndexed { i, w ->
            if (i == active) sp.setSpan(ForegroundColorSpan(0xFFC6F432.toInt()), pos, pos + w.length, f)
            pos += w.length + 1
        }
        return sp
    }
}
