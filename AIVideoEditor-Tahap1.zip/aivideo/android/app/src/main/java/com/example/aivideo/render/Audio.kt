package com.example.aivideo.render

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer

/** Mengalikan volume PCM 16-bit dengan gain yang bergantung pada waktu (ms) sejak awal video. */
class GainEnvelopeProcessor(private val gainAt: (Long) -> Float) : BaseAudioProcessor() {
    private var frames = 0L // sengaja tidak di-reset saat loop, agar envelope mengikuti waktu video

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        val ch = inputAudioFormat.channelCount
        val rate = inputAudioFormat.sampleRate
        while (inputBuffer.remaining() >= 2 * ch) {
            val g = gainAt(frames * 1000 / rate)
            repeat(ch) { out.putShort((inputBuffer.getShort() * g).toInt().coerceIn(-32768, 32767).toShort()) }
            frames++
        }
        out.flip()
    }
}

/**
 * Musik berada di level rendah selama narasi (ducking), fade in 1 dtk di awal dan fade out 2 dtk di akhir.
 * Narasi mengisi seluruh video, jadi level rendah berlaku konstan. Untuk ducking dinamis (naik saat jeda),
 * analisis aktivitas suara pada file narasi lalu ganti fungsi ini.
 */
object MusicEnvelope {
    const val DUCKED = 0.18f
    fun gain(tMs: Long, totalMs: Long): Float {
        val fadeIn = (tMs / 1000f).coerceIn(0f, 1f)
        val fadeOut = ((totalMs - tMs) / 2000f).coerceIn(0f, 1f)
        return DUCKED * minOf(fadeIn, fadeOut)
    }
}
