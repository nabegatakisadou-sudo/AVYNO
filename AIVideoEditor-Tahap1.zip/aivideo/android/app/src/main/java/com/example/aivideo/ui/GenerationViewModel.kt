package com.example.aivideo.ui

import android.media.MediaMetadataRetriever
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aivideo.ai.*
import com.example.aivideo.data.*
import com.example.aivideo.render.VideoExporter
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class GenerationViewModel(
    private val text: TextProvider, private val tts: TtsProvider, private val img: ImageProvider,
    private val music: MusicProvider, private val exporter: VideoExporter, private val cache: File,
) : ViewModel() {
    private val _s = MutableStateFlow(UiState())
    val state = _s.asStateFlow()
    private val authoring = listOf(Step.SCRIPT, Step.VOICE, Step.VISUAL, Step.MUSIC, Step.TIMELINE)

    fun setTopic(v: String) = _s.update { it.copy(topic = v) }
    fun setDuration(v: Int) = _s.update { it.copy(duration = v) }
    fun setRatio(v: String) = _s.update { it.copy(ratio = v) }
    fun setMood(v: String?) = _s.update { it.copy(mood = v) }

    /** Membuat bahan sampai timeline siap, lalu berhenti agar pengguna bisa meninjau/mengedit. */
    fun start() = viewModelScope.launch { _s.update { it.copy(error = null) }; runSteps(authoring) }

    /** Subtitle dan ekspor selalu dibuat ulang dari kondisi klip terbaru. */
    fun export() = viewModelScope.launch {
        _s.update { it.copy(output = null, error = null, status = it.status + (Step.SUBTITLE to Status.PENDING) + (Step.EXPORT to Status.PENDING)) }
        runSteps(listOf(Step.SUBTITLE, Step.EXPORT))
    }

    fun retry() = if (_s.value.status[Step.TIMELINE] == Status.DONE) export() else start()

    // ---- Operasi editor ----
    private fun edit(f: (UiState) -> UiState) = _s.update(f)
    private fun UiState.withSelected(f: (Clip) -> Clip) = copy(clips = clips.mapIndexed { i, c -> if (i == selected) f(c) else c })

    fun select(i: Int) = edit { it.copy(selected = i.coerceIn(0, (it.clips.size - 1).coerceAtLeast(0))) }
    fun setText(t: String) = edit { it.withSelected { c -> c.copy(text = t) } }

    fun move(d: Int) = edit { st ->
        val i = st.selected; val j = i + d
        if (j !in st.clips.indices) st
        else st.copy(clips = st.clips.toMutableList().also { it.add(j, it.removeAt(i)) }, selected = j)
    }

    fun delete() = edit { st ->
        if (st.clips.size <= 1) st
        else st.copy(clips = st.clips.filterIndexed { i, _ -> i != st.selected }, selected = st.selected.coerceAtMost(st.clips.size - 2))
    }

    /** Memotong narasi klip terpilih; gambar mengikuti durasi baru. */
    fun trim(startDeltaMs: Long, endDeltaMs: Long) = edit { st ->
        val c = st.clips.getOrNull(st.selected) ?: return@edit st
        val from = (c.fromMs + startDeltaMs).coerceIn(0L, (c.toMs - 500).coerceAtLeast(0L))
        val to = (c.toMs + endDeltaMs).coerceIn(from + 500, maxOf(c.voiceMs, from + 500))
        st.withSelected { it.copy(fromMs = from, toMs = to) }
    }

    /** Memisah klip terpilih di tengah: narasi dipotong dua, teks dibagi dua. */
    fun split() = edit { st ->
        val c = st.clips.getOrNull(st.selected) ?: return@edit st
        if (c.durationMs < 1000) return@edit st
        val mid = c.fromMs + c.durationMs / 2
        val words = c.text.split(" ").filter { it.isNotEmpty() }
        val k = words.size / 2
        val a = c.copy(toMs = mid, text = words.take(k).joinToString(" "))
        val b = c.copy(id = st.clips.maxOf { it.id } + 1, fromMs = mid, text = words.drop(k).joinToString(" "))
        st.copy(clips = st.clips.take(st.selected) + a + b + st.clips.drop(st.selected + 1))
    }

    // ---- Pipeline ----
    private fun mark(step: Step, st: Status) = _s.update { it.copy(status = it.status + (step to st)) }

    /** Langkah DONE dilewati (cache); "Coba lagi" hanya mengulang langkah yang gagal. */
    private suspend fun runSteps(steps: List<Step>) {
        for (step in steps) {
            if (_s.value.status[step] == Status.DONE) continue
            if (!run(step)) return
        }
    }

    private fun audioMs(path: String): Long {
        val r = MediaMetadataRetriever()
        return try { r.setDataSource(path); r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L } finally { r.release() }
    }

    private suspend fun run(step: Step): Boolean {
        mark(step, Status.RUNNING)
        return try {
            val s = _s.value
            when (step) {
                Step.SCRIPT -> { val r = text.generateScript(s.topic, s.duration, "Indonesia", "Edukasi"); _s.update { it.copy(script = r) } }
                Step.VOICE -> { val v = s.script!!.segments.mapIndexed { i, seg -> tts.synthesize(seg.narration, "default", File(cache, "voice$i.mp3")).path }
                    _s.update { it.copy(voices = v) } }
                Step.VISUAL -> { val f = s.script!!.segments.mapIndexed { i, seg -> img.image(seg.visual, s.ratio, File(cache, "img$i.png")).path }
                    _s.update { it.copy(images = f) } }
                Step.MUSIC -> { val f = s.mood?.let { music.music(it, File(cache, "music.mp3")).path }; _s.update { it.copy(music = f) } }
                Step.TIMELINE -> { val seg = s.script!!.segments
                    val clips = seg.indices.map { i ->
                        val ms = audioMs(s.voices[i]).takeIf { it > 0 } ?: ((seg[i].end - seg[i].start) * 1000L)
                        Clip(i, s.images[i], s.voices[i], ms, 0L, ms, seg[i].narration)
                    }
                    _s.update { it.copy(clips = clips, selected = 0) } }
                Step.SUBTITLE -> { val c = SubtitleEngine.buildFromClips(s.clips); _s.update { it.copy(cues = c) } }
                Step.EXPORT -> { val out = exporter.export(s.clips, File(cache, "output.mp4"), s.cues, s.music); _s.update { it.copy(output = out.path) } }
            }
            mark(step, Status.DONE); true
        } catch (e: Exception) {
            mark(step, Status.FAILED)
            _s.update { it.copy(error = "Proses gagal. Silakan coba lagi. (${e.message})") }
            false
        }
    }
}
