package com.example.aivideo.render

import android.text.SpannableString
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay
import com.example.aivideo.data.Cue
import com.example.aivideo.data.SubtitleEngine

/** Subtitle yang berubah mengikuti waktu video, ditempel (burn-in) saat ekspor. */
class SubtitleOverlay(private val cues: List<Cue>) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString =
        SubtitleEngine.textAt(cues, presentationTimeUs / 1000)

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.55f).build()
}
