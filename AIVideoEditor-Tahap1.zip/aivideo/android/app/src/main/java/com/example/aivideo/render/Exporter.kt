package com.example.aivideo.render

import android.content.Context
import android.net.Uri
import androidx.media3.common.Effects
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.*
import com.example.aivideo.data.Clip
import com.example.aivideo.data.Cue
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

interface VideoExporter { suspend fun export(clips: List<Clip>, out: File, cues: List<Cue>, music: String?): File }

/** Gambar + potongan narasi per klip + subtitle + musik latar -> MP4 (H.264/AAC) lewat Media3 Transformer. */
class Media3Exporter(private val ctx: Context) : VideoExporter {
    override suspend fun export(clips: List<Clip>, out: File, cues: List<Cue>, music: String?): File =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val images = clips.map {
                    EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(File(it.image))))
                        .setDurationUs(it.durationMs * 1000).setFrameRate(30).build()
                }
                val voices = clips.map {
                    val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(it.fromMs).setEndPositionMs(it.toMs).build()
                    EditedMediaItem.Builder(MediaItem.Builder().setUri(Uri.fromFile(File(it.voice))).setClippingConfiguration(clip).build()).build()
                }
                val sequences = mutableListOf(EditedMediaItemSequence(images), EditedMediaItemSequence(voices))
                music?.let { m ->
                    val total = clips.sumOf { it.durationMs }
                    val duck = GainEnvelopeProcessor { t -> MusicEnvelope.gain(t, total) }
                    val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(File(m))))
                        .setEffects(Effects(listOf(duck), emptyList())).build()
                    sequences += EditedMediaItemSequence(listOf(item), true) // diulang sampai video selesai
                }
                val transformer = Transformer.Builder(ctx).addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) = cont.resume(out)
                    override fun onError(composition: Composition, exportResult: ExportResult, e: ExportException) =
                        cont.resumeWithException(e)
                }).build()
                val composition = Composition.Builder(sequences).apply {
                    if (cues.isNotEmpty()) setEffects(Effects(emptyList(), listOf(
                        OverlayEffect(ImmutableList.of<TextureOverlay>(SubtitleOverlay(cues))))))
                }.build()
                transformer.start(composition, out.absolutePath)
                cont.invokeOnCancellation { transformer.cancel() }
            }
        }
}
