package com.example.aivideo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aivideo.ui.theme.Card as CardColor
import com.example.aivideo.ui.theme.Chip as ChipColor
import com.example.aivideo.ui.theme.Ink
import com.example.aivideo.ui.theme.Light
import com.example.aivideo.ui.theme.Lime
import com.example.aivideo.ui.theme.Muted

@Composable
fun Header(title: String, onBack: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        if (onBack != null) {
            IconButton(onBack, Modifier.size(44.dp).clip(CircleShape).background(CardColor)) { Text("‹", fontSize = 26.sp) }
        }
        Text(title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        trailing()
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardColor).padding(14.dp), content = content)

@Composable
fun Label(text: String) = Text(text, Modifier.padding(bottom = 8.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)

/** Baris chip yang bisa digeser; satu chip terpilih berwarna lime. */
@Composable
fun <T> Chips(items: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (key, label) ->
            val on = key == selected
            Box(
                Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(50)).background(if (on) Lime else ChipColor)
                    .clickable { onSelect(key) }.padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) Ink else Light) }
        }
    }
}

@Composable
fun LimeButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) =
    Button(onClick, modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = enabled, shape = RoundedCornerShape(14.dp)) {
        Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
    }

@Composable
fun BottomBar(current: String, onNav: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(CardColor).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
    ) {
        listOf(
            Triple("home", "Beranda", "⌂"), Triple("create", "AI", "✦"), Triple("editor", "Editor", "▦"),
            Triple("projects", "Proyek", "▭"), Triple("settings", "Setelan", "⚙"),
        ).forEach { (route, label, glyph) ->
            val on = current == route
            val color = if (on) Lime else Muted
            Column(
                Modifier.widthIn(min = 56.dp).heightIn(min = 44.dp).clip(RoundedCornerShape(12.dp)).clickable { onNav(route) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Text(glyph, color = color, fontSize = 18.sp)
                Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
