package com.example.aivideo.render

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Menyalin MP4 hasil ekspor ke galeri (Movies/AIVideoEditor). Tidak perlu izin penyimpanan di Android 10+. */
suspend fun saveToGallery(ctx: Context, file: File): String = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "AIVideo_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AIVideoEditor")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: error("Gagal menyimpan ke galeri")
    ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
    uri.toString()
}
