package com.example.aivideo.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aivideo.ui.theme.Chip as ChipColor
import com.example.aivideo.ui.theme.Ink
import com.example.aivideo.ui.theme.Lime
import com.example.aivideo.ui.theme.Muted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
internal fun Thumb(path: String, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
        }
    }
    bmp?.let { Image(it, null, modifier, contentScale = ContentScale.Crop) } ?: Box(modifier.background(ChipColor))
}

@Composable
private fun Btn(label: String, onClick: () -> Unit) = OutlinedButton(onClick, Modifier.heightIn(min = 44.dp)) { Text(label) }

private fun sec(ms: Long) = "%.1f dtk".format(ms / 1000.0)

@Composable
fun EditorScreen(vm: GenerationViewModel, onBack: () -> Unit, onExport: () -> Unit) {
    val s by vm.state.collectAsState()
    val sel = s.clips.getOrNull(s.selected)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Editor", onBack) {
            if (sel != null) Button(onExport, Modifier.heightIn(min = 44.dp)) { Text("Ekspor", fontWeight = FontWeight.ExtraBold) }
        }
        if (sel == null) {
            Text("Belum ada klip. Buat video dulu lewat tab AI.", color = Muted)
        } else {
            Text("${s.clips.size} klip · total ${sec(s.clips.sumOf { it.durationMs })}", color = Muted, fontSize = 12.sp)
            Box(
                Modifier.align(Alignment.CenterHorizontally).height(320.dp).aspectRatio(9f / 16f)
                    .clip(RoundedCornerShape(14.dp)).background(ChipColor),
            ) {
                Thumb(sel.image, Modifier.fillMaxSize())
                Text(
                    sel.text,
                    Modifier.align(Alignment.BottomCenter).padding(12.dp).clip(RoundedCornerShape(10.dp))
                        .background(Ink.copy(alpha = 0.85f)).padding(8.dp),
                    color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                )
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(s.clips, key = { _, c -> c.id }) { i, c ->
                    Column(
                        Modifier.width(76.dp).clip(RoundedCornerShape(10.dp))
                            .border(if (i == s.selected) 2.dp else 0.dp, Lime, RoundedCornerShape(10.dp))
                            .clickable { vm.select(i) },
                    ) {
                        Thumb(c.image, Modifier.fillMaxWidth().height(100.dp))
                        Text(sec(c.durationMs), Modifier.padding(6.dp), color = Muted, fontSize = 10.sp)
                    }
                }
            }
            AppCard {
                OutlinedTextField(sel.text, vm::setText, Modifier.fillMaxWidth(), label = { Text("Subtitle klip terpilih") })
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("◀", { vm.move(-1) }); Btn("▶", { vm.move(1) }); Btn("Pisah", vm::split); Btn("Hapus", vm::delete)
                }
                Spacer(Modifier.height(10.dp))
                Text("Potong narasi", color = Muted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("Awal −0,5", { vm.trim(-500, 0) }); Btn("Awal +0,5", { vm.trim(500, 0) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("Akhir −0,5", { vm.trim(0, -500) }); Btn("Akhir +0,5", { vm.trim(0, 500) })
                }
            }
        }
    }
}
