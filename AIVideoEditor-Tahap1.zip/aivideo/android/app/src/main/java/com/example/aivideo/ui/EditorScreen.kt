package com.example.aivideo.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.aivideo.ui.theme.Chip
import com.example.aivideo.ui.theme.Lime
import com.example.aivideo.ui.theme.Muted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun Thumb(path: String, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
        }
    }
    bmp?.let { Image(it, null, modifier, contentScale = ContentScale.Crop) } ?: Box(modifier.background(Chip))
}

@Composable
private fun Btn(label: String, onClick: () -> Unit) = OutlinedButton(onClick, Modifier.heightIn(min = 44.dp)) { Text(label) }

private fun sec(ms: Long) = "%.1f dtk".format(ms / 1000.0)

@Composable
fun EditorScreen(vm: GenerationViewModel, onExport: () -> Unit) {
    val s by vm.state.collectAsState()
    val sel = s.clips.getOrNull(s.selected)
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Editor", style = MaterialTheme.typography.headlineSmall)
        Text("${s.clips.size} klip · total ${sec(s.clips.sumOf { it.durationMs })}", color = Muted)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(s.clips, key = { _, c -> c.id }) { i, c ->
                Column(
                    Modifier.width(88.dp).clip(RoundedCornerShape(10.dp))
                        .border(if (i == s.selected) 2.dp else 0.dp, Lime, RoundedCornerShape(10.dp))
                        .clickable { vm.select(i) },
                ) {
                    Thumb(c.image, Modifier.fillMaxWidth().height(120.dp))
                    Text(sec(c.durationMs), Modifier.padding(6.dp), color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        if (sel != null) {
            OutlinedTextField(sel.text, vm::setText, Modifier.fillMaxWidth(), label = { Text("Subtitle klip terpilih") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("◀", { vm.move(-1) }); Btn("▶", { vm.move(1) }); Btn("Pisah", vm::split); Btn("Hapus", vm::delete)
            }
            Text("Potong narasi", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Awal −0,5", { vm.trim(-500, 0) }); Btn("Awal +0,5", { vm.trim(500, 0) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Akhir −0,5", { vm.trim(0, -500) }); Btn("Akhir +0,5", { vm.trim(0, 500) })
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onExport, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Ekspor Video") }
    }
}
