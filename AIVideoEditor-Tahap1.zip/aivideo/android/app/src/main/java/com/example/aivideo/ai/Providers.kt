package com.example.aivideo.ai

import com.example.aivideo.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

/** Provider abstraction: ganti penyedia tanpa mengubah UI. */
interface TextProvider {
    suspend fun generateScript(topic: String, duration: Int, language: String, style: String): ScriptResult
    suspend fun ideas(niche: String, count: Int): List<Idea>
    suspend fun ping(): String
}
interface TtsProvider { suspend fun synthesize(text: String, voice: String, out: File): File }
interface ImageProvider { suspend fun image(prompt: String, ratio: String, out: File): File }
interface MusicProvider { suspend fun music(mood: String, out: File): File }

class ProviderNotConfigured(name: String) : Exception("Provider $name belum dikonfigurasi")

/** Implementasikan dengan memanggil endpoint backend /api/tts dan /api/image. */
object NotConfiguredTts : TtsProvider {
    override suspend fun synthesize(text: String, voice: String, out: File): File = throw ProviderNotConfigured("TTS")
}
object NotConfiguredImage : ImageProvider {
    override suspend fun image(prompt: String, ratio: String, out: File): File = throw ProviderNotConfigured("Gambar")
}

class BackendClient(private val base: String, private val token: String) : TextProvider {
    // Server gratis bisa "tidur" dan butuh ~1 menit untuk bangun, jadi timeout dibuat longgar.
    private val http = OkHttpClient.Builder().connectTimeout(90, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS).build()
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun ping(): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$base/api/ping").header("Authorization", "Bearer $token").get().build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string()
            if (!r.isSuccessful) error(failMessage(r.code, body))
            val o = Json.parseToJsonElement(body ?: "{}").jsonObject
            fun f(k: String) = o[k]?.jsonPrimitive?.content ?: "?"
            "Terhubung ✓  Script: ${f("script")} · Suara: ${f("tts")} · Gambar: ${f("image")}"
        }
    }

    override suspend fun ideas(niche: String, count: Int): List<Idea> = withContext(Dispatchers.IO) {
        val body = json.encodeToString(IdeasRequest(niche, count)).toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("$base/api/ideas").header("Authorization", "Bearer $token").post(body).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error(failMessage(r.code, r.body?.string()))
            json.decodeFromString<IdeasResult>(r.body!!.string()).ideas
        }
    }

    override suspend fun generateScript(topic: String, duration: Int, language: String, style: String): ScriptResult =
        withContext(Dispatchers.IO) {
            val body = json.encodeToString(ScriptRequest(topic, duration, language, style))
                .toRequestBody("application/json".toMediaType())
            val req = Request.Builder().url("$base/api/script").header("Authorization", "Bearer $token").post(body).build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error(failMessage(r.code, r.body?.string()))
                json.decodeFromString<ScriptResult>(r.body!!.string())
            }
        }
}

/** Suara dan gambar lewat backend (/api/tts, /api/image). Respons berupa byte file, disimpan ke [out]. */
class BackendMedia(private val base: String, private val token: String) : TtsProvider, ImageProvider, MusicProvider {
    private val http = OkHttpClient.Builder().connectTimeout(90, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(180, java.util.concurrent.TimeUnit.SECONDS).build()

    private suspend fun post(path: String, body: String, out: File): File = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$base$path").header("Authorization", "Bearer $token")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error(failMessage(r.code, r.body?.string()))
            out.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
        }
        out
    }

    override suspend fun synthesize(text: String, voice: String, out: File): File =
        post("/api/tts", Json.encodeToString(mapOf("text" to text, "voice" to voice)), out)

    override suspend fun image(prompt: String, ratio: String, out: File): File =
        post("/api/image", Json.encodeToString(mapOf("prompt" to prompt, "ratio" to ratio)), out)

    override suspend fun music(mood: String, out: File): File = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$base/api/music/$mood").header("Authorization", "Bearer $token").get().build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error(failMessage(r.code, r.body?.string()))
            out.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
        }
        out
    }
}

/** Pesan galat yang bisa dipahami: token salah, batas laju, atau keterangan dari backend. */
private fun failMessage(code: Int, body: String?): String {
    val detail = try { Json.parseToJsonElement(body ?: "").jsonObject["detail"]?.jsonPrimitive?.content } catch (_: Exception) { null }
    return when (code) {
        401 -> "Token tidak cocok: APP_TOKEN di Render dan di GitHub harus sama persis"
        429 -> "Terlalu banyak permintaan, tunggu sebentar"
        else -> detail ?: "HTTP $code"
    }
}
