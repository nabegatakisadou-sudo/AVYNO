package com.example.aivideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.aivideo.ai.*
import com.example.aivideo.render.Media3Exporter
import com.example.aivideo.ui.*
import com.example.aivideo.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val ctx = LocalContext.current.applicationContext
    val vm: GenerationViewModel = viewModel(factory = remember {
        viewModelFactory {
            initializer {
                val media = BackendMedia(BuildConfig.BASE_URL, BuildConfig.APP_TOKEN)
                GenerationViewModel(BackendClient(BuildConfig.BASE_URL, BuildConfig.APP_TOKEN),
                    media, media, media, Media3Exporter(ctx), ctx.cacheDir)
            }
        }
    })
    NavHost(nav, "home") {
        composable("home") { HomeScreen { nav.navigate("create") } }
        composable("create") { GeneratorScreen(vm) { vm.start(); nav.navigate("progress") } }
        composable("progress") { ProgressScreen(vm) { nav.navigate("editor") } }
        composable("editor") { EditorScreen(vm) { vm.export(); nav.navigate("progress") } }
    }
}
