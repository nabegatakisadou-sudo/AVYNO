package com.example.aivideo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.aivideo.ai.*
import com.example.aivideo.render.Media3Exporter
import com.example.aivideo.render.saveToGallery
import com.example.aivideo.ui.*
import com.example.aivideo.ui.theme.AppTheme
import com.example.aivideo.ui.theme.Ink

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    val ctx = LocalContext.current.applicationContext
    val vm: GenerationViewModel = viewModel(factory = remember {
        viewModelFactory {
            initializer {
                val media = BackendMedia(BuildConfig.BASE_URL, BuildConfig.APP_TOKEN)
                GenerationViewModel(
                    BackendClient(BuildConfig.BASE_URL, BuildConfig.APP_TOKEN),
                    media, media, media, Media3Exporter(ctx), ctx.cacheDir,
                ) { saveToGallery(ctx, it) }
            }
        }
    })
    val s by vm.state.collectAsState()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route ?: "home"
    Scaffold(
        containerColor = Ink,
        bottomBar = { BottomBar(route) { dest -> nav.navigate(dest) { popUpTo("home"); launchSingleTop = true } } },
    ) { pad ->
        NavHost(nav, "home", Modifier.padding(pad)) {
            composable("home") { HomeScreen(s.clips.isNotEmpty(), { nav.navigate("create") }, { nav.navigate("editor") }, { nav.navigate("ideas") }, { nav.navigate("templates") }) }
            composable("create") { GeneratorScreen(vm, { nav.popBackStack() }) { vm.startNew(); nav.navigate("progress") } }
            composable("progress") { ProgressScreen(vm, { nav.navigate("editor") }) { nav.popBackStack() } }
            composable("editor") { EditorScreen(vm, { nav.popBackStack() }) { vm.export(); nav.navigate("progress") } }
            composable("ideas") { IdeasScreen(vm, { nav.popBackStack() }) { nav.navigate("create") } }
            composable("templates") { TemplatesScreen(vm, { nav.popBackStack() }) { nav.navigate("create") } }
            composable("projects") { SoonScreen("Proyek") }
            composable("settings") { SettingsScreen(BuildConfig.BASE_URL, vm) }
        }
    }
}
