package com.example.aivideo.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aivideo.data.Status
import com.example.aivideo.data.Step
import com.example.aivideo.ui.theme.Card as CardColor
import com.example.aivideo.ui.theme.Ink
import com.example.aivideo.ui.theme.Light
import com.example.aivideo.ui.theme.Lime
import com.example.aivideo.ui.theme.Muted

@Composable
fun HomeScreen(hasProject: Boolean, onCreate: () -> Unit, onOpenEditor: () -> Unit, onIdeas: () -> Unit, onTemplates: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text("Selamat datang", color = Muted, fontSize = 12.sp)
            Text("Halo, Kreator", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        Column(
            Modifier.fillMaxWidth().heightIn(min = 168.dp).clip(RoundedCornerShape(22.dp)).background(Lime)
                .clickable(onClick = onCreate).padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("AI CONTENT STUDIO", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Column {
                Text("+ BUAT VIDEO AI", color = Ink, fontSize = 30.sp, lineHeight = 33.sp, fontWeight = FontWeight.ExtraBold)
                Text("Dari satu ide jadi video siap upload", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf<Triple<String, String, (() -> Unit)?>>(
                Triple("💡", "Ide Konten", onIdeas), Triple("▦", "Template", onTemplates),
                Triple("🎙", "Suara AI", null), Triple("🖼", "Gambar AI", null),
            ).forEach { (icon, label, action) ->
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(CardColor)
                        .let { if (action != null) it.clickable(onClick = action) else it }.padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(icon, fontSize = 18.sp)
                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (action == null) Text("Segera", fontSize = 9.sp, color = Muted)
                }
            }
        }
        Text("Proyek terakhir", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        if (hasProject) {
            AppCard(Modifier.clickable(onClick = onOpenEditor)) {
                Text("Proyek yang sedang dikerjakan", fontWeight = FontWeight.Bold)
                Text("Ketuk untuk membuka editor", color = Muted, fontSize = 12.sp)
            }
        } else {
            Text("Belum ada proyek. Ketuk + BUAT VIDEO AI untuk mulai.", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun GeneratorScreen(vm: GenerationViewModel, onBack: () -> Unit, onGenerate: () -> Unit) {
    val s by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Header("Buat Video AI", onBack)
        AppCard {
            Label("Topik / ide")
            OutlinedTextField(s.topic, vm::setTopic, Modifier.fillMaxWidth(), placeholder = { Text("Contoh: manfaat tanaman kunyit") })
        }
        Column { Label("Rasio video"); Chips(listOf("9:16" to "9:16", "16:9" to "16:9", "1:1" to "1:1", "4:5" to "4:5"), s.ratio, vm::setRatio) }
        Column { Label("Durasi"); Chips(listOf(15 to "15 dtk", 30 to "30 dtk", 45 to "45 dtk", 60 to "60 dtk"), s.duration, vm::setDuration) }
        Column {
            Label("Gaya")
            Chips(listOf("Edukasi", "Dokumenter", "Sinematik", "Motivasi", "Lucu", "Fakta", "Top 5", "Storytelling", "Berita").map { it to it }, s.style, vm::setStyle)
        }
        Column { Label("Suara"); Chips(listOf("female" to "Wanita", "male" to "Pria"), s.voice, vm::setVoice) }
        Column {
            Label("Musik latar")
            Chips(listOf<Pair<String?, String>>("calm" to "Calm", "cinematic" to "Cinematic", "energetic" to "Energik", null to "Tanpa"), s.mood, vm::setMood)
        }
        LimeButton("✦  Generate Video", enabled = s.topic.length >= 3, onClick = onGenerate)
        Text(
            "Bahasa: Indonesia. Pemakaian mengikuti batas kunci gratis Anda.",
            Modifier.fillMaxWidth(), color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun CopyRow(label: String, value: String) {
    val clipboard = LocalClipboardManager.current
    Label(label)
    Text(value, fontSize = 13.sp)
    OutlinedButton({ clipboard.setText(AnnotatedString(value)) }, Modifier.heightIn(min = 44.dp)) { Text("Salin") }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun ProgressScreen(vm: GenerationViewModel, onEdit: () -> Unit, onBack: () -> Unit) {
    val s by vm.state.collectAsState()
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Header(if (s.output != null) "Siap Upload" else "Membuat video", onBack)
        AppCard {
            Step.entries.forEach { step ->
                val (mark, color) = when (s.status[step]) {
                    Status.DONE -> "✓" to Lime
                    Status.RUNNING -> "…" to Light
                    Status.FAILED -> "✗" to MaterialTheme.colorScheme.error
                    else -> "○" to Muted
                }
                Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(mark, color = color, fontWeight = FontWeight.Bold)
                    Text(step.label, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        s.error?.let {
            AppCard {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                LimeButton("Coba lagi") { vm.retry() }
            }
        }
        if (s.status[Step.TIMELINE] == Status.DONE) {
            OutlinedButton(onEdit, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Buka Editor") }
        }
        s.outputUri?.let { uri ->
            AppCard {
                Text("Video tersimpan di galeri (folder Movies/AIVideoEditor).", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                LimeButton("Buka video") {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                        )
                    } catch (_: Exception) { }
                }
            }
            s.script?.let { sc ->
                AppCard {
                    CopyRow("Judul", sc.title)
                    CopyRow("Deskripsi", sc.description)
                    CopyRow("Hashtag", sc.hashtags.joinToString(" ") { if (it.startsWith("#")) it else "#$it" })
                }
            }
        }
    }
}

@Composable
fun SoonScreen(title: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Header(title)
        Text("Segera hadir.", color = Muted)
    }
}

@Composable
fun IdeasScreen(vm: GenerationViewModel, onBack: () -> Unit, onUse: () -> Unit) {
    val s by vm.state.collectAsState()
    var niche by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Ide Konten", onBack)
        AppCard {
            Label("Niche")
            OutlinedTextField(niche, { niche = it }, Modifier.fillMaxWidth(), placeholder = { Text("Contoh: tanaman herbal") })
            Spacer(Modifier.height(10.dp))
            LimeButton(if (s.ideasBusy) "Membuat ide…" else "Buat ide", enabled = niche.length >= 2 && !s.ideasBusy) { vm.loadIdeas(niche) }
        }
        s.ideasError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        s.ideas.forEach { idea ->
            AppCard {
                Text(idea.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${idea.style} · ${idea.duration} dtk", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedButton({ vm.useIdea(idea); onUse() }, Modifier.heightIn(min = 44.dp)) { Text("Buat Video") }
            }
        }
    }
}

private data class Template(val name: String, val desc: String, val style: String, val duration: Int, val color: Color)

@Composable
fun TemplatesScreen(vm: GenerationViewModel, onBack: () -> Unit, onUse: () -> Unit) {
    val templates = listOf(
        Template("Edukasi", "Hook, 3 poin, CTA", "Edukasi", 30, Color(0xFF4FC08D)),
        Template("Motivasi", "Semangat dan penutup kuat", "Motivasi", 30, Color(0xFFE8A317)),
        Template("Fakta", "5 fakta singkat", "Fakta", 30, Color(0xFFA99CFF)),
        Template("Top 5", "Daftar peringkat", "Top 5", 45, Color(0xFFFF8A6B)),
        Template("Storytelling", "Cerita singkat", "Storytelling", 45, Color(0xFF8FB8FF)),
        Template("Berita", "Ringkas dan faktual", "Berita", 30, Color(0xFFC6F432)),
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Template", onBack)
        Text("Pilih template, lalu isi topiknya.", color = Muted, fontSize = 13.sp)
        templates.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { t ->
                    Column(
                        Modifier.weight(1f).height(150.dp).clip(RoundedCornerShape(14.dp)).background(t.color)
                            .clickable { vm.useTemplate(t.style, t.duration); onUse() }.padding(12.dp),
                        verticalArrangement = Arrangement.Bottom,
                    ) {
                        Text(t.name, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(t.desc, color = Ink, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(baseUrl: String, vm: GenerationViewModel) {
    val s by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Setelan")
        AppCard {
            Label("Alamat backend")
            Text(baseUrl, fontSize = 13.sp)
            Text("Berisi alamat Render jika APK dibangun dengan alamat tersebut.", color = Muted, fontSize = 12.sp)
        }
        AppCard {
            Label("Tes koneksi")
            Text("Memeriksa alamat, token, dan penyedia AI yang aktif. Server gratis bisa butuh sekitar 1 menit untuk bangun.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            LimeButton(if (s.pingBusy) "Memeriksa…" else "Tes koneksi", enabled = !s.pingBusy) { vm.ping() }
            s.pingResult?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, fontSize = 13.sp, color = if (it.startsWith("Terhubung")) Lime else MaterialTheme.colorScheme.error)
            }
        }
    }
}
