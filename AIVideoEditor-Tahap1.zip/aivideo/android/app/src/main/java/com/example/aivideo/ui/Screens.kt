package com.example.aivideo.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aivideo.data.Status
import com.example.aivideo.data.Step
import com.example.aivideo.ui.theme.Card as CardColor
import com.example.aivideo.ui.theme.Ink
import com.example.aivideo.ui.theme.Light
import com.example.aivideo.ui.theme.Lime
import com.example.aivideo.ui.theme.Muted

@Composable
fun HomeScreen(hasProject: Boolean, onCreate: () -> Unit, onOpenEditor: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column {
            Text("Selamat datang", color = Muted, fontSize = 12.sp)
            Text("Halo, Kreator", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        }
        Column(
            Modifier.fillMaxWidth().heightIn(min = 168.dp).clip(RoundedCornerShape(22.dp)).background(Lime)
                .clickable(onClick = onCreate).padding(22.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("AI CONTENT STUDIO", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Column {
                Text("+ BUAT VIDEO AI", color = Ink, fontSize = 30.sp, lineHeight = 33.sp, fontWeight = FontWeight.ExtraBold)
                Text("Dari satu ide jadi video siap upload", color = Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("💡" to "Ide Konten", "▦" to "Template", "🎙" to "Suara AI", "🖼" to "Gambar AI").forEach { (icon, label) ->
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(CardColor).padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(icon, fontSize = 18.sp)
                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("Segera", fontSize = 9.sp, color = Muted)
                }
            }
        }
        Text("Proyek terakhir", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        if (hasProject) {
            AppCard(Modifier.clickable(onClick = onOpenEditor)) {
                Text("Proyek yang sedang dikerjakan", fontWeight = FontWeight.Bold)
                Text("Ketuk untuk membuka editor", color = Muted, fontSize = 12.sp)
            }
        } else {
            Text("Belum ada proyek. Ketuk + BUAT VIDEO AI untuk mulai.", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
fun GeneratorScreen(vm: GenerationViewModel, onBack: () -> Unit, onGenerate: () -> Unit) {
    val s by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Header("Buat Video AI", onBack)
        AppCard {
            Label("Topik / ide")
            OutlinedTextField(s.topic, vm::setTopic, Modifier.fillMaxWidth(), placeholder = { Text("Contoh: manfaat tanaman kunyit") })
        }
        Column { Label("Rasio video"); Chips(listOf("9:16" to "9:16", "16:9" to "16:9", "1:1" to "1:1", "4:5" to "4:5"), s.ratio, vm::setRatio) }
        Column { Label("Durasi"); Chips(listOf(15 to "15 dtk", 30 to "30 dtk", 45 to "45 dtk", 60 to "60 dtk"), s.duration, vm::setDuration) }
        Column {
            Label("Gaya")
            Chips(listOf("Edukasi" to "Edukasi", "Dokumenter" to "Dokumenter", "Sinematik" to "Sinematik", "Motivasi" to "Motivasi", "Lucu" to "Lucu"), s.style, vm::setStyle)
        }
        Column { Label("Suara"); Chips(listOf("female" to "Wanita", "male" to "Pria"), s.voice, vm::setVoice) }
        Column {
            Label("Musik latar")
            Chips(listOf<Pair<String?, String>>("calm" to "Calm", "cinematic" to "Cinematic", "energetic" to "Energik", null to "Tanpa"), s.mood, vm::setMood)
        }
        LimeButton("✦  Generate Video", enabled = s.topic.length >= 3, onClick = onGenerate)
        Text(
            "Bahasa: Indonesia. Pemakaian mengikuti batas kunci gratis Anda.",
            Modifier.fillMaxWidth(), color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun CopyRow(label: String, value: String) {
    val clipboard = LocalClipboardManager.current
    Label(label)
    Text(value, fontSize = 13.sp)
    OutlinedButton({ clipboard.setText(AnnotatedString(value)) }, Modifier.heightIn(min = 44.dp)) { Text("Salin") }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun ProgressScreen(vm: GenerationViewModel, onEdit: () -> Unit, onBack: () -> Unit) {
    val s by vm.state.collectAsState()
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Header(if (s.output != null) "Siap Upload" else "Membuat video", onBack)
        AppCard {
            Step.entries.forEach { step ->
                val (mark, color) = when (s.status[step]) {
                    Status.DONE -> "✓" to Lime
                    Status.RUNNING -> "…" to Light
                    Status.FAILED -> "✗" to MaterialTheme.colorScheme.error
                    else -> "○" to Muted
                }
                Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(mark, color = color, fontWeight = FontWeight.Bold)
                    Text(step.label, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        s.error?.let {
            AppCard {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                LimeButton("Coba lagi") { vm.retry() }
            }
        }
        if (s.status[Step.TIMELINE] == Status.DONE) {
            OutlinedButton(onEdit, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Buka Editor") }
        }
        s.outputUri?.let { uri ->
            AppCard {
                Text("Video tersimpan di galeri (folder Movies/AIVideoEditor).", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                LimeButton("Buka video") {
                    try {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(uri), "video/mp4")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                        )
                    } catch (_: Exception) { }
                }
            }
            s.script?.let { sc ->
                AppCard {
                    CopyRow("Judul", sc.title)
                    CopyRow("Deskripsi", sc.description)
                    CopyRow("Hashtag", sc.hashtags.joinToString(" ") { if (it.startsWith("#")) it else "#$it" })
                }
            }
        }
    }
}

@Composable
fun SoonScreen(title: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Header(title)
        Text("Segera hadir.", color = Muted)
    }
}
