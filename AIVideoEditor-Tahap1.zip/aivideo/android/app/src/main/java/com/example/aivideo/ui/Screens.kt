package com.example.aivideo.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.aivideo.data.Status
import com.example.aivideo.data.Step
import com.example.aivideo.ui.theme.Muted

@Composable
fun HomeScreen(onCreate: () -> Unit) = Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
    Text("Halo, Kreator", style = MaterialTheme.typography.headlineMedium)
    Text("Dari satu ide jadi video siap upload", color = Muted)
    Button(onCreate, Modifier.fillMaxWidth().heightIn(min = 120.dp)) { Text("+ BUAT VIDEO AI", style = MaterialTheme.typography.titleLarge) }
}

@Composable
fun GeneratorScreen(vm: GenerationViewModel, onGenerate: () -> Unit) {
    val s by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Buat Video AI", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(s.topic, vm::setTopic, Modifier.fillMaxWidth(), label = { Text("Topik / ide") })
        Text("Durasi")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 45, 60).forEach { FilterChip(s.duration == it, { _ -> vm.setDuration(it) }, { Text("$it dtk") }) }
        }
        Text("Rasio")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("9:16", "16:9", "1:1", "4:5").forEach { FilterChip(s.ratio == it, { _ -> vm.setRatio(it) }, { Text(it) }) }
        }
        Text("Musik latar")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf<Pair<String?, String>>("calm" to "Calm", "cinematic" to "Cinematic", "energetic" to "Energik", null to "Tanpa")
                .forEach { (key, label) -> FilterChip(s.mood == key, { _ -> vm.setMood(key) }, { Text(label) }) }
        }
        Spacer(Modifier.weight(1f))
        Button(onGenerate, Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = s.topic.length >= 3) { Text("Generate Video") }
    }
}

@Composable
fun ProgressScreen(vm: GenerationViewModel, onEdit: () -> Unit) {
    val s by vm.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Membuat video", style = MaterialTheme.typography.headlineSmall)
        Step.entries.forEach { step ->
            val mark = when (s.status[step]) { Status.DONE -> "✓"; Status.RUNNING -> "…"; Status.FAILED -> "✗"; else -> "○" }
            Text("$mark  ${step.label}")
        }
        s.error?.let { Text(it, color = MaterialTheme.colorScheme.error); Button({ vm.retry() }) { Text("Coba lagi") } }
        s.output?.let { Text("Video tersimpan: $it") }
        if (s.status[Step.TIMELINE] == Status.DONE) Button(onEdit, Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Buka Editor") }
    }
}
