plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}
// BASE_URL dan APP_TOKEN bisa diisi lewat variabel lingkungan saat build (dipakai GitHub Actions).
val baseUrl = System.getenv("BASE_URL")?.takeIf { it.isNotBlank() } ?: "http://10.0.2.2:8000"
val appToken = System.getenv("APP_TOKEN")?.takeIf { it.isNotBlank() } ?: "ganti-token-ini"

android {
    namespace = "com.example.aivideo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.aivideo"
        minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1"
        buildConfigField("String", "BASE_URL", "\"$baseUrl\"")
        buildConfigField("String", "APP_TOKEN", "\"$appToken\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { disable += "UnsafeOptInUsageError" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.navigation:navigation-compose:2.8.2")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
